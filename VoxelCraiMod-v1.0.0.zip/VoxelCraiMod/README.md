# 🚀 VoxelCraiMod - SH-based Voxel Lighting

<div align="center">

![VoxelCrai Banner](https://img.shields.io/badge/VoxelCrai-SH%20Lighting-blue?style=for-the-badge&logo=minecraft)
![Minecraft](https://img.shields.io/badge/Minecraft-1.21.3+-green?style=for-the-badge)
![Fabric](https://img.shields.io/badge/Fabric-0.16.7+-orange?style=for-the-badge)
![License](https://img.shields.io/badge/License-MIT-yellow?style=for-the-badge)

**Воксельное освещение на основе Spherical Harmonics паттернов**

*Без трассировки лучей — чистая математика SH для 60+ FPS*

</div>

---

## 📖 Описание

VoxelCraiMod — это мод для Minecraft Fabric, который реализует продвинутое воксельное освещение с использованием Spherical Harmonics (SH) паттернов. В отличие от традиционного трассирования лучей, мод использует предвычисленные паттерны освещения для достижения высокой производительности.

### ✨ Ключевые особенности

- **🔮 SH-based Global Illumination** — Мягкое непрямое освещение через сферические гармоники
- **🌑 Динамические тени** — Негативные SH коэффициенты для быстрых мягких теней
- **✨ Аппроксимированные отражения** — Specular через направленный SH запрос
- **⚡ 60+ FPS** — Оптимизировано для AMD Radeon VII и выше
- **📊 10,000 паттернов** — Каждый паттерн 1KB для детального освещения
- **🔧 Настраиваемость** — Слайдеры для количества паттернов (1k-100k), SH bands (3-5)

---

## 🏗️ Архитектура

```
┌─────────────────────────────────────────────────────────────────┐
│                    VoxelCraiMod Architecture                     │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐       │
│  │   Pattern    │───▶│   Pattern    │───▶│    SSBO      │       │
│  │  Generator   │    │    Buffer    │    │   (GPU)      │       │
│  │   (CPU)      │    │  (10k x 1KB) │    │   10 MB      │       │
│  └──────────────┘    └──────────────┘    └──────────────┘       │
│         │                                        │               │
│         ▼                                        ▼               │
│  ┌──────────────┐                        ┌──────────────┐       │
│  │   Chunk      │                        │   GLSL       │       │
│  │   Events     │                        │  Shaders     │       │
│  │   (Load/     │                        │  (SH Eval)   │       │
│  │   Unload)    │                        └──────────────┘       │
│  └──────────────┘                                │               │
│                                                  ▼               │
│                                          ┌──────────────┐       │
│                                          │   Final      │       │
│                                          │   Output     │       │
│                                          │   (HDR)      │       │
│                                          └──────────────┘       │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### LightPattern1KB Структура

```java
// Портировано из Rust прототипа
struct LightPattern1KB {
    long id;              // 8 байт - идентификатор
    // padding           // 8 байт
    short[3] directLight;    // 6 байт - RGB fp16 прямое освещение
    short[3] indirectLight;  // 6 байт - RGB fp16 непрямое освещение
    byte[256] shCoeffs;      // 256 байт - SH коэффициенты (до 4 bands)
    byte[512] materialData;  // 512 байт - данные материала
    short roughness;         // 2 байт - шероховатость (fp16)
    short metallic;          // 2 байт - металличность (fp16)
    // ... остальные поля
    // Итого: 1024 байт
}
```

### Spherical Harmonics Bands

| Band | Коэффициентов | Назначение |
|------|---------------|------------|
| 0    | 1             | DC (ambient) |
| 1    | 3             | Направленный свет |
| 2    | 5             | Мягкие тени |
| 3    | 7             | Детали (опционально) |
| 4    | 9             | Высокое качество |

---

## 📦 Установка

### Требования

- **Minecraft:** 1.21.3 или выше
- **Fabric Loader:** 0.16.7+
- **Fabric API:** Последняя версия
- **Java:** 21+
- **GPU:** Vulkan/OpenGL 4.3+ (для SSBO)
- **Рекомендуется:** AMD Radeon VII / NVIDIA RTX 2060 или выше

### Опциональные зависимости

- **Iris Shaders:** 1.7.0+ (для интеграции с шейдер-паками)
- **Sodium:** 0.5.0+ (для оптимизации рендера)

### Шаги установки

1. **Установите Fabric Loader**
   ```bash
   # Скачайте Fabric Installer с https://fabricmc.net/use/
   java -jar fabric-installer.jar
   ```

2. **Скачайте мод**
   ```bash
   # Поместите voxelcrai-mod-1.0.0.jar в папку mods
   cp voxelcrai-mod-1.0.0.jar ~/.minecraft/mods/
   ```

3. **Установите Fabric API**
   ```bash
   # Скачайте с https://modrinth.com/mod/fabric-api
   cp fabric-api-*.jar ~/.minecraft/mods/
   ```

4. **(Опционально) Установите Iris + Sodium**
   ```bash
   cp iris-*.jar ~/.minecraft/mods/
   cp sodium-*.jar ~/.minecraft/mods/
   ```

5. **Запустите игру**
   - Шейдер-пак автоматически создастся в `shaderpacks/VoxelCrai-SH-Lighting.zip`
   - Активируйте через меню Iris (если установлен)

---

## ⚙️ Конфигурация

Файл конфигурации: `config/voxelcrai.json`

```json
{
  "patternCount": 10000,
  "shBands": 4,
  "patternDensity": 2,
  "maxPatternsPerChunk": 512,
  "enableReflections": true,
  "enableShadows": true,
  "enableGI": true,
  "giIntensity": 1.0,
  "shadowIntensity": 1.0,
  "reflectionIntensity": 0.8,
  "asyncPatternGeneration": true,
  "updateIntervalTicks": 20,
  "debugMode": false
}
```

### Параметры

| Параметр | Диапазон | Описание |
|----------|----------|----------|
| `patternCount` | 1,000 - 100,000 | Количество паттернов (больше = выше качество) |
| `shBands` | 3 - 5 | Количество SH bands (больше = точнее тени) |
| `patternDensity` | 1 - 4 | Плотность выборки (1 = каждый блок) |
| `giIntensity` | 0.0 - 2.0 | Интенсивность GI |
| `shadowIntensity` | 0.0 - 2.0 | Интенсивность теней |
| `reflectionIntensity` | 0.0 - 1.0 | Интенсивность отражений |

---

## 🎮 Производительность

### Тестовые результаты (AMD Radeon VII, 1080p)

| Настройка | Паттерны | SH Bands | FPS | VRAM |
|-----------|----------|----------|-----|------|
| Low       | 1,000    | 3        | 120+ | 1 MB |
| Medium    | 5,000    | 3        | 90+  | 5 MB |
| High      | 10,000   | 4        | 60+  | 10 MB |
| Ultra     | 50,000   | 5        | 45+  | 50 MB |

### Советы по оптимизации

1. **Снизьте количество паттернов** на слабых GPU
2. **Используйте 3 SH bands** для баланса качества/производительности
3. **Включите Sodium** для общей оптимизации рендера
4. **Увеличьте `patternDensity`** для снижения нагрузки

---

## 🔮 Алгоритм SH Освещения

### Генерация паттернов (CPU)

```java
// Для каждого блока в чанке:
for (int i = 0; i < SAMPLE_COUNT; i++) {
    float[] dir = sampleDirections[i];  // Фибоначчиева сфера
    float visibility = traceVisibility(chunk, pos, dir);
    projectToSH(dir, visibility, shValues);
}
// Нормализация в [-127, 127] для i8 хранения
```

### Реконструкция в шейдере (GPU)

```glsl
// 🔮 Вычисление SH базисных функций
float[16] basis = computeSHBasis(normal, bands);

// 🌟 Реконструкция освещения
float irradiance = 0.0;
for (int i = 0; i < numCoeffs; i++) {
    irradiance += coeffs[i] * basis[i];
}

// 💡 Применение косинусной свертки для diffuse
irradiance *= cosineLobeCoeffs[band];
```

---

## 🛠️ Сборка из исходников

```bash
# Клонирование репозитория
git clone https://github.com/voxelcrai/voxelcrai-mod.git
cd voxelcrai-mod

# Сборка
./gradlew build

# Результат в build/libs/voxelcrai-mod-1.0.0.jar
```

### Требования для сборки

- JDK 21+
- Gradle 8.5+

---

## 📚 Благодарности

- **Rethinking Voxels** (gri573) — вдохновение для структуры шейдер-пака
- **Iris Shaders Team** — API для интеграции шейдеров
- **Fabric Team** — модлоадер и API

---

## 📄 Лицензия

MIT License — см. [LICENSE-MIT](LICENSE-MIT)

---

## 🤝 Вклад в проект

1. Fork репозитория
2. Создайте feature branch (`git checkout -b feature/amazing-feature`)
3. Commit изменения (`git commit -m 'Add amazing feature'`)
4. Push в branch (`git push origin feature/amazing-feature`)
5. Откройте Pull Request

---

<div align="center">

**🚀 VoxelCraiMod — Воксельное освещение будущего! 🚀**

*Made with ❤️ and Spherical Harmonics*

</div>
